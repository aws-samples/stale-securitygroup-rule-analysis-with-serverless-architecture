import boto3
import boto3.session
from collections import namedtuple
from .utilities import tag_parser

class NetworkInterface:
    """
    A class used to return details on network interfaces.

    Attributes
    ----------
    aws_profile: str
        The AWS profile to use - as saved in credential file.
    aws_region: str
        The AWS region to make API calls against
    
    Methods
    -------
    list_interfaces(self, **kwargs)
        Returns a list of namedtuples of network interfaces in the region
    get_interface(self, nic_id:list,**kwargs)
        Returns the details of the network interface provided in nic_id
    """


    def __init__(self,aws_profile=None,aws_region=None) -> None:
        if aws_profile:
            self.aws_profile = aws_profile
            self.aws_region = aws_region
            self._session = boto3.session.Session(
                profile_name=self.aws_profile,region_name=self.aws_region
            )
            self._client = self._session.client('ec2')
        else:
            self._client = boto3.client('ec2')
        self._interfaces = namedtuple('interfaces',['name','id','vpc_id','subnet_id'])
        self._interface_details = namedtuple(
            'interface_details',
            [
                *self._interfaces._fields,
                'security_group_ids',
                'network_acl',
                'route_table',
                'type',
                'attachment_properties',
                'az',
                'private_ip_address',
                'private_dns_name',
                'public_ip_address',
                'public_dns_name',
            ],
            defaults=[None,None]
        )

    def list_interfaces(self,**kwargs) -> list:
        """
        Lists network interfaces in the region.

        Parameters
        ----------
        **kwargs: see boto3 docs
            allows the use of boto3 keyword args for filtering results.
        
        Returns
        -------
        List of interfaces namedtuples
        """
        response = self._client.describe_network_interfaces(**kwargs)
        iface_list = response['NetworkInterfaces']
        while response.get('NextToken'):
            response = self._client.describe_network_interfaces(NextToken=response['NextToken'],**kwargs)
            if len(response['NetworkInterfaces']) > 0:
                iface_list.extend(response['NetworkInterfaces'])
        self.iface_names = [
            tag_parser(
                client=self._client,Filters=[
                    {'Name':'key','Values':['Name']},
                    {'Name':'resource-id','Values':[i['NetworkInterfaceId']]}]
            )
            for i in iface_list
        ]
        self.iface_ids = [i['NetworkInterfaceId'] for i in iface_list]
        self.iface_vpc_ids = [i['VpcId'] for i in iface_list]
        self.iface_subnet_ids = [i['SubnetId'] for i in iface_list]
        self.interfaces = [
            self._interfaces(
                name=self.iface_names[i],
                id=self.iface_ids[i],
                vpc_id=self.iface_vpc_ids[i],
                subnet_id=self.iface_subnet_ids[i]
            )
            for i in range(len(self.iface_vpc_ids))
        ]

        return self.interfaces

    def get_interface(self,nic_id:list,**kwargs) -> namedtuple:
        """
        Returns details of a single network interface.

        Parameters
        ----------
        nic_id: list
            A single item list containing the eni-id of the network interface to return details on.
        **kwargs: see boto3 docs
            allows the use of boto3 keyword args for filtering results.
        
        Returns
        -------
        namedtuple interface_details containing the interface details.
        """
        self.nic_id = nic_id
        response = self._client.describe_network_interfaces(NetworkInterfaceIds=self.nic_id,**kwargs)['NetworkInterfaces'][0]
        nacl = self._client.describe_network_acls(Filters=[{'Name':'association.subnet-id','Values':[response['SubnetId']]}])['NetworkAcls'][0]['NetworkAclId']
        try:
            rt = self._client.describe_route_tables(Filters=[{'Name':'association.subnet-id','Values':[response['SubnetId']]}])['RouteTables'][0]['RouteTableId']
        except IndexError:
             rt = self._client.describe_route_tables(
                    Filters=[{'Name':'vpc-id','Values':[response['VpcId']]},{'Name':'association.main','Values':['true']}]
                )['RouteTables'][0]['RouteTableId']
        self.interface_details = self._interface_details(
            name=tag_parser(
                client=self._client,Filters=[
                    {'Name':'key','Values':['Name']},
                    {'Name':'resource-id','Values':self.nic_id}
                    ]
                ),
            id=response['NetworkInterfaceId'],
            vpc_id=response['VpcId'],
            subnet_id=response['SubnetId'],
            security_group_ids=[i['GroupId'] for i in response['Groups']],
            network_acl=nacl,
            route_table=rt,
            type=response['InterfaceType'],
            attachment_properties=response.get('Attachment'),
            az=response['AvailabilityZone'],
            private_ip_address=response['PrivateIpAddress'],
            private_dns_name=response.get('PrivateDnsName')
        )

        if 'Association' in response.keys():

            if len(response['Association'].get('PublicDnsName')) > 0:
                self.interface_details = self.interface_details._replace(
                    public_dns_name=response['Association'].get('PublicDnsName')
                )

            if len(response['Association'].get('PublicIp')) > 0:
                self.interface_details = self.interface_details._replace(
                    public_ip_address=response['Association'].get('PublicIp')
                )

        return self.interface_details

    def get_interfaces_by_sg_id(self,sg_id:list,**kwargs) -> list:
        """
        Returns list of interfaces with the given security group attached.

        Parameters
        ----------
        sg_id: list
            A single item list containing the group-id of the security group to filter network interfaces by
        **kwargs: see boto3 docs
            allows the use of boto3 keyword args for filtering results.
        
        Returns
        -------
        List of interfaces namedtuples
        """
        self.sg_id=sg_id
        response = self.list_interfaces(Filters=[{'Name':'group-id','Values':self.sg_id}],**kwargs)
        return response