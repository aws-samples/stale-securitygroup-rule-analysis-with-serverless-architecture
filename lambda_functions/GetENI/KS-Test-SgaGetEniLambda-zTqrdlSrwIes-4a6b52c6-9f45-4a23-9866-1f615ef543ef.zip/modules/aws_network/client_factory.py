import boto3

class ClientFactory:
    """
    A class used to return boto3 clients and responses for a module. 
    This shouldn't be called directly, and should instead be called via 
    a module

    Attributes
    ----------
    aws_profile: str
        The AWS profile to use - as saved in credential file.
    aws_region: str
        The AWS region to make API calls against
    resource: str
        The resource to return API calls for
    
    Methods
    -------
    return_call(self, **kwargs)
        Returns AWS API calls for the resource specified in the resource attribute
    tag_parser(self, nic_id:list,**kwargs)
        Returns the value of a resource tag
    """

    def __init__(self,aws_profile=None,aws_region=None,resource=None,role_arn=None,role_session_name=None) -> None:
        self.resource = resource
        if aws_profile:
            self.aws_profile = aws_profile
            self.aws_region = aws_region
            self._session = boto3.session.Session(
                profile_name=self.aws_profile,region_name=self.aws_region
            )
        else:
            self._session = boto3.session.Session()
        if role_arn:
            sts_client = self._session.client('sts')
            self.role_arn = role_arn
            self.role_session_name = role_session_name
            sts_credentials = sts_client.assume_role(RoleArn=self.role_arn,RoleSessionName=self.role_session_name)['Credentials']
            self._session = boto3.session.Session(
                aws_access_key_id=sts_credentials['AccessKeyId'],
                aws_secret_access_key=sts_credentials['SecretAccessKey'],
                aws_session_token=sts_credentials['SessionToken'])

        self._client = self._session.client('ec2')

    def return_call(self,**kwargs) -> dict:
        if self.resource == 'igw':
            api_call = self._client.describe_internet_gateways(**kwargs)
        elif self.resource == 'eip':
            api_call = self._client.describe_addresses(**kwargs)
        elif self.resource == 'vpce':
            api_call = self._client.describe_vpc_endpoints(**kwargs)
        elif self.resource == 'vpn_connection':
            api_call = self._client.describe_vpn_connections(**kwargs)
        elif self.resource == 'customer_gw':
            api_call = self._client.describe_customer_gateways(**kwargs)
        elif self.resource == 'vpn_gw':
            api_call = self._client.describe_vpn_gateways(**kwargs)
        elif self.resource == 'security_group':
            api_call = self._client.describe_security_groups(**kwargs)
        else:
            raise NotImplementedError

        return api_call
    
    def tag_parser(self,**kwargs):
        response = self._client.describe_tags(**kwargs)
        try:
            tag = response['Tags'][0]['Value']
        except:
            tag = None
        
        return tag