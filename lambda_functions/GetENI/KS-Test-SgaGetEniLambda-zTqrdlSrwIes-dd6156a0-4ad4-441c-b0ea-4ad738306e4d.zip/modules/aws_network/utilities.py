def tag_parser(client,**kwargs):
    response = client.describe_tags(**kwargs)
    try:
        tag = response['Tags'][0]['Value']
    except:
        tag = None
    
    return tag

def subnet_is_public(client,route_table_id:list,**kwargs) -> bool:
    response = client.describe_route_tables(RouteTableIds=route_table_id,**kwargs)
    is_public = [route for i in response['RouteTables'] for route in i['Routes'] if route.get('DestinationCidrBlock') == '0.0.0.0/0' and route.get('GatewayId')]
    if len(is_public) > 0:
        is_public = True
    else:
        is_public = False
    
    return is_public

def rt_is_main(client,route_table_id:list,**kwargs) -> bool:
    response = client.describe_route_tables(RouteTableIds=route_table_id,**kwargs)
    is_main = [route['Main'] for i in response['RouteTables'] for route in i['Associations'] if route['Main'] == True]
    if len(is_main) > 0:
    
        return True
    else:
    
        return False